// Ready or Not — сервер аккаунтов. Запуск: node server.js  (Node 16+, без зависимостей)
const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const PORT=process.env.PORT||3000,ROOT=__dirname,DB=path.join(process.env.DATA_DIR||path.join(ROOT,'data'),'db.json');
fs.mkdirSync(path.dirname(DB),{recursive:true});
let db={users:{},sessions:{}};try{db=JSON.parse(fs.readFileSync(DB,'utf8'))}catch(e){}
const flush=()=>{const t=DB+'.tmp';fs.writeFileSync(t,JSON.stringify(db));fs.renameSync(t,DB)};
const hp=(p,s)=>crypto.scryptSync(p,s,32).toString('hex');
const MIME={'.html':'text/html; charset=utf-8','.png':'image/png','.jpg':'image/jpeg','.webp':'image/webp','.svg':'image/svg+xml','.css':'text/css','.js':'text/javascript'};
const tries={};setInterval(()=>{for(const k in tries)delete tries[k]},60000);
const send=(res,c,o,h={})=>{res.writeHead(c,{'Content-Type':'application/json','Cache-Control':'no-store',...h});res.end(JSON.stringify(o))};
const body=req=>new Promise(r=>{let b='';req.on('data',d=>{b+=d;if(b.length>3e6)req.destroy()});req.on('end',()=>{try{r(JSON.parse(b||'{}'))}catch(e){r({})}})});
const pub=u=>({name:u.name,nick:u.nick,avatar:u.avatar,bio:u.bio,role:u.role,created:u.created});
const who=req=>{const m=/sid=([a-f0-9]+)/.exec(req.headers.cookie||'');const k=m&&db.sessions[m[1]];return k&&db.users[k]?{k,sid:m[1],u:db.users[k]}:null};
const cookie=(req,sid,age)=>`sid=${sid}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${age}`+(req.headers['x-forwarded-proto']==='https'?'; Secure':'');
const clip=(s,n)=>String(s||'').slice(0,n);
http.createServer(async(req,res)=>{
 const url=new URL(req.url,'http://x');
 if(url.pathname.startsWith('/api/')){
  const ip=req.socket.remoteAddress;tries[ip]=(tries[ip]||0)+1;if(tries[ip]>60)return send(res,429,{error:'Слишком много запросов, подождите минуту.'});
  const s=who(req),r=url.pathname.slice(5);
  if(r==='me')return send(res,200,s?{user:pub(s.u),data:s.u.data||{}}:{user:null});
  if(req.method!=='POST'&&req.method!=='PUT')return send(res,405,{error:'method'});
  const b=await body(req);
  if(r==='register'||r==='login'){
   const name=clip(b.name,20).trim(),k=name.toLowerCase(),pass=String(b.pass||'');
   if(r==='register'){
    if(!/^[\w\-а-яё]{3,20}$/i.test(name))return send(res,400,{error:'Имя: 3–20 символов (буквы, цифры, _ -).'});
    if(pass.length<6)return send(res,400,{error:'Пароль минимум 6 символов.'});
    if(db.users[k])return send(res,400,{error:'Это имя уже занято.'});
    const salt=crypto.randomBytes(16).toString('hex');
    db.users[k]={name,nick:name,avatar:clip(b.avatar,8)||'👮',bio:'',role:'',created:new Date().toISOString().slice(0,10),salt,hash:hp(pass,salt),data:{}};
   }else{
    const u=db.users[k];if(!u||!crypto.timingSafeEqual(Buffer.from(hp(pass,u.salt)),Buffer.from(u.hash)))return send(res,400,{error:'Неверное имя или пароль.'});
   }
   const sid=crypto.randomBytes(24).toString('hex');db.sessions[sid]=k;flush();
   return send(res,200,{user:pub(db.users[k]),data:db.users[k].data||{}},{'Set-Cookie':cookie(req,sid,2592000)});
  }
  if(r==='logout'){if(s){delete db.sessions[s.sid];flush()}return send(res,200,{ok:1},{'Set-Cookie':cookie(req,'',0)})}
  if(!s)return send(res,401,{error:'Войдите в аккаунт.'});
  if(r==='profile'){Object.assign(s.u,{nick:clip(b.nick,24)||s.u.name,avatar:clip(b.avatar,8)||s.u.avatar,bio:clip(b.bio,300),role:clip(b.role,16)});flush();return send(res,200,{user:pub(s.u)})}
  if(r==='data'){s.u.data={P:b.P||{},PLANS:b.PLANS||{}};flush();return send(res,200,{ok:1})}
  return send(res,404,{error:'not found'});
 }
 let p=decodeURIComponent(url.pathname);if(p==='/')p='/index.html';
 const f=path.join(ROOT,path.normalize(p));
 if(!f.startsWith(ROOT)||/[\\/](data|server\.js|package\.json|node_modules)([\\/]|$)/.test(f.slice(ROOT.length)))return send(res,404,{error:'not found'});
 fs.readFile(f,(e,d)=>{if(e)return send(res,404,{error:'not found'});res.writeHead(200,{'Content-Type':MIME[path.extname(f)]||'application/octet-stream'});res.end(d)});
}).listen(PORT,()=>console.log('Ready or Not: http://localhost:'+PORT));
