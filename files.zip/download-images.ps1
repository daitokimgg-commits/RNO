# Скачивает карты и изображения локаций Ready or Not с wiki.gg в папку ./images
# Запуск:  powershell -ExecutionPolicy Bypass -File download-images.ps1
# После скачивания замените в index.html строку:
#   const IMG='https://readyornot.wiki.gg/images/';
# на:
#   const IMG='./images/';

$base = 'https://readyornot.wiki.gg/images/'
$out  = Join-Path $PSScriptRoot 'images'
New-Item -ItemType Directory -Force $out | Out-Null

$files = @(
  # Локации (базовая игра)
  '4U_Gas_Station_location.png','San_Uriel_Condominiums_location.png','213_Park_Homes_location.png','Brixley_Talent_Time_location.png',"Sullivan's_Slope_location.png",'Brisa_Cove_location.png','Mindjot_Data_Center_location.png','Kawayu_Beach_location.png','Los_Sueños_Postal_Service_location.png','Voll_Health_House_location.png','Watt_Community_College_location.png','Costa_Vino_Border_Reserve_location.png','Clemente_Hotel_location.png','Neon_Nightclub_location.png',"Caesar's_Car_Dealership_location.png",'Cherryesa_Farm_location.png','Coastal_Grove_Medical_Center_location.png','Port_Hokan_location.png',
  # Карты (базовая игра)
  '4U_Gas_Station_Map.png','San_Uriel_Condominiums_Map.png','213_Park_Homes_Map.png','Brixley_Talent_Time_Map.png',"Sullivan's_Slope_Map.png",'Brisa_Cove_Map.png','Mindjot_Data_Center_Map.png','Kawayu_Beach_Map.png','Los_Sueños_Postal_Service_Map.png','Voll_Health_House_Map.png','Watt_Community_College_Map.png','Costa_Vino_Border_Reserve_Map.png','Clemente_Hotel_Map.png','Neon_Nightclub_Map.png',"Caesar's_Car_Dealership_Map.png",'Cherryesa_Farm_Map.png','Coastal_Grove_Medical_Center_Map.png','Port_Hokan_Map.png',
  # Локации (DLC)
  'Dorms.png','BriefingMedia_Narcos_Main_Image.png','Lawmaker_Mansion.png','BriefingMedia_Boat_Briefing.png','HeavyWell_A-101_Rig.png','BriefingMedia_Island_Briefing.png','BriefingMedia_FastFood_Briefing.png','BriefingMedia_Apartments_Briefing.png','Tower_MainStair.png',
  # Карты (DLC)
  'BriefingMedia_Dorms_Map.png','BriefingMedia_Narcos_Map.png','BriefingMedia_Lawmaker_Ground_Floor_Map.png','BriefingMedia_Lawmaker_Middle_Floor_Map.png','BriefingMedia_Lawmaker_Top_Floor_Map.png','Yacht_map.png','BriefingMedia_Rig_Lower_Level_Map.png','BriefingMedia_Rig_Middle_Level_Map.png','BriefingMedia_Rig_Top_Level_Map.png','BriefingMedia_Island_First_Floor_Map.png','BriefingMedia_Island_Second_Floor_Map.png','BriefingMedia_FastFood_Map.png','BriefingMedia_Apartments_Basement_Map.png','BriefingMedia_Apartments_First_Floor_Map.png','BriefingMedia_Apartments_Second_Floor_Map.png','ANewAmericaMapFloor1.png','ANewAmericaMapFloor2.png','ANewAmericaMapFloor3.png','ANewAmericaMapFloor4.png'
)

$ok=0;$fail=0
foreach($f in $files){
  $url = $base + [uri]::EscapeDataString($f)
  $dest = Join-Path $out $f
  try {
    Invoke-WebRequest -Uri $url -OutFile $dest -TimeoutSec 30 -ErrorAction Stop
    Write-Host ("OK   " + $f) -ForegroundColor Green
    $ok++
  } catch {
    Write-Host ("FAIL " + $f) -ForegroundColor Red
    $fail++
  }
}
Write-Host ("`nГотово: " + $ok + " загружено, " + $fail + " не удалось.") -ForegroundColor Cyan
